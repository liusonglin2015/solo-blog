title: 用户态收发包lib库简述
date: '2024-09-09 17:27:26'
updated: '2024-09-10 20:19:32'
tags: [C]
permalink: /articles/2024/09/09/1725874046040.html
---
![](https://b3logfile.com/bing/20200211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> * libpcap
>   * 是一个捕获和分析网络数据包的库，可以在用户态进行数据包的收发和处理。
>   * 适用于网络监控、数据包分析等场景。
> * PF\_RING
>   * 是一个高性能的数据包捕获库，可以在用户态进行数据包的收发和处理。它提供了一系列的优化技术，包括零拷贝、多队列等，以提高数据包处理的性能。
> * libnet
>   * 是一个用于构建和发送网络数据包的库，可以在用户态生成和发送各种类型的网络数据包。

> * libevent
>   * [https://github.com/libevent/libevent](https://github.com/libevent/libevent)
>   * libevent 提供了更多的功能扩展，除了事件驱动的 I/O，还包括 DNS 解析、HTTP 客户端和服务器、RPC 等。
>   * 是一个较为成熟和广泛使用的库，有很大的用户社区支持。
>   * Linux 上使用 epoll 作为底层的事件驱动机制。
> * libev
>   * [https://github.com/enki/libev](https://github.com/enki/libev)
>   * [http://dist.schmorp.de/libev/](http://dist.schmorp.de/libev/)
>   * 提供了更底层的事件处理接口，相对更接近底层。它提供了事件循环、定时器、信号等基本的事件处理功能。
>   * 更专注于事件驱动的异步 I/O。
>   * Linux 上使用 epoll 作为底层的事件驱动机制。
> * libuv
>   * [https://github.com/libuv/libuv](https://github.com/libuv/libuv)
>   * libuv 是 Node.js 的底层事件驱动引擎，因此在 Node.js 生态系统中得到广泛应用和支持。
>   * libuv 提供了更多的功能扩展，除了事件驱动的 I/O，还包括线程池、定时器、异步文件操作等。
>   * Linux 上使用 epoll 作为底层的事件驱动机制。

