title: gdb调试技巧
date: '2024-09-10 14:59:47'
updated: '2024-09-10 20:18:58'
tags: [C]
permalink: /articles/2024/09/10/1725951587076.html
---
![](https://b3logfile.com/bing/20201011.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# gdb调试技巧

* 使用gdb调试带参数的程序：

```SHELL
gdb --args your_program arg1 arg2 arg3
```

- 或者在gdb的命令行中，执行：

```
run arg1 arg2 arg3
```

> run 或 r：开始运行程序.
> break <位置> 或 b <位置>：在指定位置设置断点。位置可以是函数名，行号，或者是组合(例如main.c:10).
> continue 或 c：从当前位置继续运行程序，直到下一个断点或程序结束.
> next 或 n：执行下一行代码，如果下一行代码是函数调用，那么将整个函数作为一个单元执行.
> step 或 s：执行下一行代码，如果下一行代码是函数调用，那么会进入函数内部.
> print <表达式> 或 p <表达式>：打印表达式的值.
> info breakpoints：列出所有的断点.
> delete <断点号>：删除指定的断点.
> quit 或 q：退出GDB.

