title: Linux下nginx源码部署
date: '2024-09-13 17:13:56'
updated: '2024-09-19 13:21:04'
tags: [nginx部署]
permalink: /articles/2024/09/13/1726218836301.html
---
![](https://b3logfile.com/bing/20200227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# nginx部署

> 依赖库的安装包下载(RedHat/Debian)：

```bash
yum install -y pcre pcre-devel
yum install -y zlib zlib-devel
yum install -y openssl openssl-devel
```

```bash
apt-get install libpcre3 libpcre3-dev
apt-get install zlib1g-dev
apt-get install openssl libssl-dev
```

- 【pcre zlib openssl】 也可以提前下载安装包行离线安装:

> [https://pkgs.org/](https://pkgs.org/)

- nginx源码包下载：

> [https://nginx.org/en/download.html](https://nginx.org/en/download.html)

- 下载完成后，执行解压缩、配置、编译、安装命令：

  ```bash
  tar zxvf nginx-1.20.1.tar.gz
  ./configure
  make
  make install
  ```
- 配置时默认不加载ssl模块，如需使用，在配置时指定：

  ```
  ./configure --with-http_ssl_module
  ```
- 安装成功后，查看nginx支持命令：

```
[root@ ~]# /usr/local/nginx/sbin/nginx -h
nginx version: nginx/1.20.1
Usage: nginx [-?hvVtTq] [-s signal] [-p prefix]
[-e filename] [-c filename] [-g directives]
Options:
-?,-h         : this help
-v            : show version and exit
-V            : show version and configure options then exit
-t            : test configuration and exit
-T            : test configuration, dump it and exit
-q            : suppress non-error messages during configuration testing
-s signal     : send signal to a master process: stop, quit, reopen, reload
-p prefix     : set prefix path (default: /usr/local/nginx/)
-e filename   : set error log file (default: logs/error.log)
-c filename   : set configuration file (default: conf/nginx.conf)
-g directives : set global directives out of configuration file
```


| 常用命令         |                                       |
| ---------------- | ------------------------------------- |
| 启动nginx        | /usr/local/nginx/sbin/nginx           |
| 停止nginx        | /usr/local/nginx/sbin/nginx -s stop   |
| 重新加载配置     | /usr/local/nginx/sbin/nginx -s reload |
| 测试配置的完整性 | /usr/local/nginx/sbin/nginx -t        |

# nginx配置

- 使用默认配置文件：/usr/local/nginx/conf/nginx.conf
- 例子：为了解决10.0.0.9的HTTP服务无法被外部访问的问题，通过开放server(10.0.0.1)部署nginx，然后通过代理间接访问10.0.0.9的http服务。

> (代理10.0.0.9的54321【HTTP】端口)

```conf
#user  nginx;
worker_processes  10;
 
error_log  /var/log/nginx/error.log warn;
pid        /var/run/nginx.pid;
 
worker_rlimit_nofile 307200;
events
{
    use epoll;
    worker_connections 40460;
}
 
 
http {
    include       mime.types;
    default_type  application/octet-stream;
 
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';
 
    access_log  /var/log/nginx/access.log  main;
 
    sendfile        on;
    #tcp_nopush     on;
 
    #keepalive_timeout  0;
    keepalive_timeout  65;
 
    #gzip  on;
 
    server {
        listen       80;
        server_name  localhost;
 
        access_log  /var/log/nginx/access.log  main;
 
        location / {
            root   html;
            index  index.html index.htm;
        }
    }
    server {
        listen       80;
        server_name  mysql.com;
 
        access_log  /var/log/nginx/access.log  main;
 
        location / {
            proxy_pass    http://10.0.0.9:54321/;
            proxy_redirect default;
        }
        location /phpmyadmin/ {
            proxy_pass    http://10.0.0.9:54321/phpmyadmin/;
            proxy_redirect default;
        }
    }
}
```

> 本地主机绑定host： 10.0.0.1   mysql.com
> 然后访问mysql页面： [http://mysql.com/phpmyadmin/](http://mysql.com/phpmyadmin/)
> 到此，nginx的安装及部署已成功。
