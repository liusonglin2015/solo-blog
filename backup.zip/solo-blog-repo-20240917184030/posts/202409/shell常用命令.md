title: shell常用命令
date: '2024-09-10 15:08:42'
updated: '2024-09-10 20:29:40'
tags: [Shell]
permalink: /articles/2024/09/10/1725952122064.html
---
# shell常用命令


* 查看路径下所有文件数量:
  `find root/ -type f | wc -l`
* 查看可执行文件所依赖的动态链接库：
  `ldd demo_recv`

