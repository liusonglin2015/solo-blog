title: Linux下Elasticsearch+Kibana安装部署
date: '2024-09-13 16:21:30'
updated: '2024-09-13 16:27:02'
tags: [ES部署]
permalink: /articles/2024/09/13/1726215690272.html
---
![](https://b3logfile.com/bing/20230524.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> ES安装包下载官方链接：
> https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-6.6.2.tar.gz
> kibana安装包下载官方链接：
> https://artifacts.elastic.co/downloads/kibana/kibana-6.6.2-linux-x86_64.tar.gz
> 二者需要安装相同的版本

# ES安装步骤

## 初始化安装目录

```bash
[root@zhulin es]# cat /etc/redhat-release
CentOS Linux release 7.9.2009 (Core)
[root@zhulin es]# mkdir -p /export/servers
[root@zhulin es]# mkdir -p /usr/local/elasticsearch/data
[root@zhulin es]# mkdir -p /usr/local/elasticsearch/logs
[root@zhulin es]# tar zxvf elasticsearch-6.6.2.tar.gz -C /export/servers/
[root@zhulin es]# cd /export/servers/
[root@zhulin servers]# mv elasticsearch-6.6.2 elasticsearch
```

## 修改配置文件

- 涉及字段：cluster.name、node.name、path.data、path.logs、network.host、http.port

> vim elasticsearch/config/elasticsearch.yml

```yml
# Use a descriptive name for your cluster:
cluster.name: my-application
# 
# Use a descriptive name for the node:
node.name: node-1
# 
# Path to directory where to store the data (separate multiple locations by comma):
path.data: /usr/local/elasticsearch/data
# 
# Path to log files:
path.logs: /usr/local/elasticsearch/logs
# 
# Set the bind address to a specific IP (IPv4 or IPv6):
network.host: 192.168.0.161
# 
# Set a custom port for HTTP:
http.port: 9200
```

## 运行遇到的问题

### 系统未安装JDK

```bash
[root@zhulin servers]# ./elasticsearch/bin/elasticsearch
which: no java in (/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin)
could not find java; set JAVA_HOME or ensure java is in PATH
```

- 修复：安装JDK1.8版本

```
[root@zhulin servers]# yum search java|grep jdk
[root@zhulin servers]# yum install java-1.8.0-openjdk
[root@zhulin servers]# java -version
   openjdk version "1.8.0_292"
   OpenJDK Runtime Environment (build 1.8.0_292-b10)
   OpenJDK 64-Bit Server VM (build 25.292-b10, mixed mode)
```

### 不能使用root权限

```
[root@zhulin servers]# ./elasticsearch/bin/elasticsearch
[2021-06-11T16:23:31,584][WARN ][o.e.b.ElasticsearchUncaughtExceptionHandler]
[node-1] uncaught exception in thread [main]
org.elasticsearch.bootstrap.StartupException: java.lang.RuntimeException:
can not run elasticsearch as root
```

- 修复：创建并使用普通用户权限运行ES

```
[root@zhulin servers]# useradd es
[root@zhulin servers]# passwd es
[root@zhulin servers]# chown -R es:es /export/servers/elasticsearch
[root@zhulin servers]# chown -R es:es /usr/local/elasticsearch
[root@zhulin servers]# su es
[es@zhulin servers]$
```

> ES运行成功后，开放两服务个端口：
> 9200 是ES节点与外部通讯使用的端口。（是http协议的restful接口）
> 9300是ES节点之间通讯使用的端口。（是集群间tcp通讯端口）

```
[es@zhulin servers]$ nohup ./elasticsearch/bin/elasticsearch &
[root@zhulin ~]# netstat -ntlp | grep java
tcp6       0      0 192.168.0.161:9200          :::*       LISTEN      7964/java
tcp6       0      0 192.168.0.161:9300          :::*       LISTEN      7964/java
```

---

> 备注：
> 
> > CentOS6.X系统上运行出现的问题(SecComp及max_map_count)
> > 问题修复参考：  https://www.cnblogs.com/socketqiang/p/11363024.html

# kibana安装步骤

```
[root@zhulin es]# tar zxvf kibana-6.6.2-linux-x86_64.tar.gz -C /run/
[root@zhulin es]# cd /run/kibana-6.6.2-linux-x86_64/
```

> 修改配置文件：config/kibana.yml

```
# Kibana is served by a back end server. This setting specifies the port to use.
server.port: 80
 
# To allow connections from remote users, set this parameter to a non-loopback address.
server.host: "192.168.0.161"
 
# new add 
elasticsearch.url: "http://192.168.0.161:9200"
```

> 直接后台运行Kibana（没有问题）

```
[root@zhulin kibana-6.6.2-linux-x86_64]# nohup bin/kibana &
[root@zhulin kibana-6.6.2-linux-x86_64]# netstat -ntlp | grep node
tcp   0   0 192.168.0.161:80    0.0.0.0:*     LISTEN     8196/bin/../node/bi
```

![image.png](https://b3logfile.com/file/2024/09/image-4steXlQ.png)

