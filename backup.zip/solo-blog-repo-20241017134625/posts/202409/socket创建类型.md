title: socket创建类型
date: '2024-09-10 13:29:25'
updated: '2024-09-19 13:22:05'
tags: [socket]
permalink: /articles/2024/09/10/1725946165218.html
---
![](https://b3logfile.com/bing/20221205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# socket创建类型

```c
int socket(int domain, int type, int protocol);
```

> domain:
> 常用协议族如下：
> AF\_INET IPv4协议
> AF\_INET6 IPv6协议
> AF\_UNIX 本地进程间通信

> type:
> 常用套接字类型如下：
> SOCK\_STREAM: 提供有序、可靠、双向、基于连接的字节流。这种类型的套接字使用TCP协议。
> SOCK\_DGRAM: 提供无连接的、不可靠的数据报服务。这种类型的套接字使用UDP协议。
> SOCK\_RAW: 提供原始网络协议访问。

> protocol:
> 常用套接字协议如下：
> PPROTO\_TCP: TCP传输协议
> IPPROTO\_UDP: UDP传输协议
> 0: 使用默认协议（SOCK\_STREAM默认使用TCP，SOCK\_DGRAM默认使用UDP）。

* 创建socket(AF\_INET, SOCK\_RAW, IPPROTO\_UDP) 后并绑定监听端口33633，测试看实际并没有监听该端口，而是所有UDP报文均接收。

> 使用原始套接字socket(AF\_INET, SOCK\_RAW, IPPROTO\_UDP)创建后，无法直接绑定监听端口，因为原始套接字操作的是IP层的数据，而不是传输层的数据。原始套接字会接收到所有经过本机的IP数据报，而不仅仅是目标端口匹配的UDP包。
>
> 如果你只想监听特定端口的UDP包，可以使用普通的UDP套接字socket(AF\_INET, SOCK\_DGRAM, 0)，然后使用bind函数绑定监听端口。
