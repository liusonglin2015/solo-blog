title: union共用体使用技巧
date: '2024-09-09 17:50:09'
updated: '2024-09-10 20:19:12'
tags: [C]
permalink: /articles/2024/09/09/1725875409481.html
---
![](https://b3logfile.com/bing/20210403.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# union

* 在C语言中，union是一种特殊的数据类型，它允许在同一内存位置存储不同的数据类型。union的大小由其最大的成员确定，所有成员共享同一块内存。

```C
typedef struct {
	int a;
	int b;
} Struct1;
typedef struct {
	double c;
	double d;
} Struct2;
union MyUnion {
	Struct1 s1;
	Struct2 s2;
};
```

> <span style="color: green;">在这个例子中，Struct1的大小是8字节（假设int的大小是4字节），Struct2的大小是16字节（假设double的大小是8字节）。因此，MyUnion的大小是16字节，即Struct2的大小。</span>

> <mark><span style="color: red;">注意，在任何时候，MyUnion只能存储s1或s2，不能同时存储两者。如果你先写入s1，然后写入s2，那么s1的值就会被覆盖。</span> </mark>

