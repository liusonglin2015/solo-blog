title: grafana使用配置
date: '2024-09-13 18:23:50'
updated: '2024-09-19 13:20:55'
tags: [grafana部署]
permalink: /articles/2024/09/13/1726223030568.html
---
![](https://b3logfile.com/bing/20200601.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

- grafana下载及安装步骤： [Documentation | Grafana Labs](https://grafana.com/docs/)
- grafana配置443端口https访问：

> 修改默认端口(3000)：
> grafana配置样例：/etc/grafana/grafana.ini
> grafana中默认生效的配置：/usr/share/grafana/conf/defaults.ini
> 创建本地证书命令：
>
> ```
> openssl req -x509 -out localhost.crt -keyout localhost.key \
>  -newkey rsa:2048 -nodes -sha256
> -days 10000
> -subj '/CN=localhost' -extensions EXT -config <(
> printf "[dn]\nCN=localhost\n[req]\ndistinguished_name = dn\n[EXT]\nsubjectAltName=DNS:localhost\nkeyUsage=digitalSignature\nextendedKeyUsage=serverAuth")
> ```

> 执行后生成：localhost.crt和localhost.key，放到/usr/share/grafana/conf/目录下；
> /usr/share/grafana/conf/defaults.ini中server默认配置：

```
[server]
# Protocol (http, https, h2, socket)
protocol = http
 
# The ip address to bind to, empty will bind to all interfaces
http_addr =
 
# The http port to use
http_port = 3000
 
# The public facing domain name used to access grafana from a browser
domain = localhost
 
# Redirect to correct domain if host header does not match domain
# Prevents DNS rebinding attacks
enforce_domain = false
 
# The full public facing url
root_url = %(protocol)s://%(domain)s:%(http_port)s/
 
# Serve Grafana from subpath specified in `root_url` setting. By default it is set to `false` for compatibility reasons.
serve_from_sub_path = false
 
# Log web requests
router_logging = false
 
# the path relative working path
static_root_path = public
 
# enable gzip
enable_gzip = false
 
# https certs & key file
cert_file =
cert_key =
```

> 修改为：

```
[server]
# Protocol (http, https, h2, socket)
protocol = https
 
# The ip address to bind to, empty will bind to all interfaces
http_addr =
 
# The http port to use
http_port = 443
 
# The public facing domain name used to access grafana from a browser
domain = localhost
 
# Redirect to correct domain if host header does not match domain
# Prevents DNS rebinding attacks
enforce_domain = false
 
# The full public facing url
root_url = %(protocol)s://%(domain)s:%(http_port)s/
 
# Serve Grafana from subpath specified in `root_url` setting. By default it is set to `false` for
 compatibility reasons.
serve_from_sub_path = false
 
# Log web requests
router_logging = false
 
# the path relative working path
static_root_path = public
 
# enable gzip
enable_gzip = false
 
# https certs & key file
cert_file = /usr/share/grafana/conf/localhost.crt
cert_key = /usr/share/grafana/conf/localhost.key
```

- 最后systemctl restart grafana-server
- 重启失败，查看/var/log/grafana/grafana.log错误信息：

`t=2021-04-12T14:42:44+0800 lvl=eror msg="Stopped HTTPServer" logger=server reason="failed to open listener on address 0.0.0.0:443: listen tcp 0.0.0.0:443: bind: permission denied"`

- 命令行执行下面命令，即可解决问题：

```
sudo setcap 'cap_net_bind_service=+ep' /usr/sbin/grafana-server
```

## grafana数据迁移

- 把需要迁移的数据源：**/var/lib/grafana/grafana.db** 拷贝到新环境中进行覆盖操作，重启生效；
- 数据迁移**grafana.db**包括：帐号信息, 图表信息，变量信息等；
- 数据移植后grafana启动报错：

```bash
root@A01-R06-I30-17-1Z54352:~# systemctl status grafana-server
● grafana-server.service - Grafana instance
   Loaded: loaded (/usr/lib/systemd/system/grafana-server.service; disabled; vendor preset: enabled)
   Active: failed (Result: start-limit-hit) since Mon 2021-04-12 15:23:32 CST; 4min 14s ago
     Docs: http://docs.grafana.org
  Process: 98921 ExecStart=/usr/sbin/grafana-server --config=${CONF_FILE} --pidfile=${PID_FILE_DIR}/grafana-server.pid --packaging=deb cfg:default.path
 Main PID: 98921 (code=exited, status=1/FAILURE)
 
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: grafana-server.service: Unit entered failed state.
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: grafana-server.service: Failed with result 'exit-code'.
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: grafana-server.service: Service hold-off time over, scheduling restart.
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: Stopped Grafana instance.
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: grafana-server.service: Start request repeated too quickly.
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: Failed to start Grafana instance.
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: grafana-server.service: Unit entered failed state.
Apr 12 15:23:32 A01-R06-I30-17-1Z54352.JD.LOCAL systemd[1]: grafana-server.service: Failed with result 'start-limit-hit'.
```

- /var/log/grafana/grafana.log中正常，/var/log/syslog中出现报错：

```log
Apr 12 15:52:52 A01-R06-I30-17-1Z54352 grafana-server[136658]: t=2021-04-12T15:52:52+0800 lvl=info msg="Starting DB migrations" logger=migrator
Apr 12 15:52:52 A01-R06-I30-17-1Z54352 grafana-server[136658]: service init failed: failed to check table existence: unable to open database file: permission denied
Apr 12 15:52:52 A01-R06-I30-17-1Z54352 systemd[1]: grafana-server.service: Main process exited, code=exited, status=1/FAILURE
```

- grafana.db的权限修改为（777），忽略下述警告:

`t=2021-04-12T15:20:50+0800 lvl=warn msg="SQLite database file has broader permissions than it should" logger=sqlstore path=/var/lib/grafana/grafana.db mode=-rw-r--r-- expected=-rw-r-----`

## grafana支持免密登录

- vim /usr/share/grafana/conf/defaults.ini  开启匿名登录：
  ![image.png](https://b3logfile.com/file/2024/09/image-sVzKd3I.png)
- 并在grafana配置页面上将user添加到新创建的组织中即可。
